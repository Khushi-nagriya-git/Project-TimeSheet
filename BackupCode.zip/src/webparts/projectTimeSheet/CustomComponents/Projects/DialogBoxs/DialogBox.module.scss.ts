/* tslint:disable */
require("./DialogBox.module.css");
const styles = {
  dialogTitle: 'dialogTitle_9e1fcc5f',
  buttonIcon: 'buttonIcon_9e1fcc5f',
  dialogContentText: 'dialogContentText_9e1fcc5f',
  deleteButton: 'deleteButton_9e1fcc5f'
};

export default styles;
/* tslint:enable */