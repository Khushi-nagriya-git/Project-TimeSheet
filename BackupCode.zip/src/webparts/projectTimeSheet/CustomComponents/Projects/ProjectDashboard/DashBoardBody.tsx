import * as React from 'react';
import { Box } from "@mui/material";
import { PieChart } from '@mui/x-charts/PieChart';
import { WebPartContext } from "@microsoft/sp-webpart-base";

// Example Data (You can replace it with dynamic data from props.project)
const desktopOS = [
  { id: 1, label: 'Estimated Hours', value: 60 }, // Example value
  { id: 2, label: 'Logged Hours', value: 25 },
];

// Example valueFormatter function (this can be customized)
const valueFormatter = (value: number) => `${value} hrs`;

const DashBoardBody = (props: { project: any; context: WebPartContext }) => {

  const data = [
    { id: 1, label: 'Estimated Hours', value: props.project?.ProjectHours || 60 },
    { id: 2, label: 'Logged Hours', value: 25 },
  ];

  return (
    <React.Fragment>
      {/* Box to contain the chart */}
      <Box sx={{ height: "auto", backgroundColor: "red", padding: 2 }}>
        <h3>Project Hours Overview</h3>
        {/* <PieChart
          series={[
            {
              data, // Using dynamic data
              highlightScope: { fade: 'global', highlight: 'item' },
              faded: { innerRadius: 30, additionalRadius: -30, color: 'gray' },
            
            },
          ]}
          height={200}
        /> */}
      </Box>
    </React.Fragment>
  );
};

export default DashBoardBody;
