/* tslint:disable */
require("./AppHeader.module.css");
const styles = {
  bt_ah_AppHeader: 'bt_ah_AppHeader_e1b1cc68',
  bt_ah_CompanyLogo: 'bt_ah_CompanyLogo_e1b1cc68',
  bt_ah_HeaderText: 'bt_ah_HeaderText_e1b1cc68',
  bt_ah_UserName: 'bt_ah_UserName_e1b1cc68',
  bt_ah_HomeIcon: 'bt_ah_HomeIcon_e1b1cc68'
};

export default styles;
/* tslint:enable */