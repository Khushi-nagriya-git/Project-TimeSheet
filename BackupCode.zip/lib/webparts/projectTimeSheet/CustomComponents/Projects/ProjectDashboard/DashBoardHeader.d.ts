import { WebPartContext } from "@microsoft/sp-webpart-base";
declare const DashBoardHeader: (props: {
    project: any;
    context: WebPartContext;
}) => JSX.Element;
export default DashBoardHeader;
//# sourceMappingURL=DashBoardHeader.d.ts.map