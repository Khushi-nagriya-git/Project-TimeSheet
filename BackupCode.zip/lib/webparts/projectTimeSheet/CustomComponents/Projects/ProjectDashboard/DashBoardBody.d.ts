import { WebPartContext } from "@microsoft/sp-webpart-base";
declare const DashBoardBody: (props: {
    project: any;
    context: WebPartContext;
}) => JSX.Element;
export default DashBoardBody;
//# sourceMappingURL=DashBoardBody.d.ts.map