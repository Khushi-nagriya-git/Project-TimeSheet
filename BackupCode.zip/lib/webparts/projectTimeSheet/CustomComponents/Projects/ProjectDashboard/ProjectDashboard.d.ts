import { IProjectDashboardProps } from "./IProjectDashboardProps";
declare const ProjectDashboard: (props: IProjectDashboardProps) => JSX.Element;
export default ProjectDashboard;
//# sourceMappingURL=ProjectDashboard.d.ts.map