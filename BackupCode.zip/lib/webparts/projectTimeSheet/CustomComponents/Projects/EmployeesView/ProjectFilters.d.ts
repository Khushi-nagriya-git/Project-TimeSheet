/// <reference types="react" />
import { React } from "../../../../../index";
interface ProjectFiltersProps {
    onProjectFilterChange: (selectedValues: string[]) => void;
    onProjectStatusChange: (selectedValues: string[]) => void;
    setSearchQuery: React.Dispatch<React.SetStateAction<string>>;
    setFilteredProjects: React.Dispatch<React.SetStateAction<any>>;
    filteredProjects: any;
    myDataActiveLink: any;
    searchQuery: string;
    projectsData: any;
    departmentNames: any;
    onDepartmentFilterChange: any;
}
declare const ProjectFilters: React.FC<ProjectFiltersProps>;
export default ProjectFilters;
//# sourceMappingURL=ProjectFilters.d.ts.map