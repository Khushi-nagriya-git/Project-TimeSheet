/// <reference types="react" />
import { React, IProjectProps } from "../../../../index";
declare const Project: React.FC<IProjectProps>;
export default Project;
//# sourceMappingURL=Project.d.ts.map