import * as React from "react";
interface JobsHeaderProps {
    onJobFilterChange: (selectedValues: string[]) => void;
    onJobStatusChange: (selectedValues: string[]) => void;
    setSearchQuery: React.Dispatch<React.SetStateAction<string>>;
    setFilteredJobs: React.Dispatch<React.SetStateAction<any>>;
    filteredJobs: any;
    searchQuery: string;
    projectsData: any;
    jobsData: any;
    onJobsAssigneesChange: any;
    isUserAdmin: any;
    isUserProjectTeam: any;
    isUserReportingManager: any;
    isUserProjectManager: any;
}
declare const JobsFiltersandSearch: React.FC<JobsHeaderProps>;
export default JobsFiltersandSearch;
//# sourceMappingURL=JobsFiltersandSearch.d.ts.map