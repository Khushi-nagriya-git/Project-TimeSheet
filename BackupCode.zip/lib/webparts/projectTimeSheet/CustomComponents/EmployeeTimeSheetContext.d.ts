import * as React from 'react';
import { ReactNode } from 'react';
import { ProjectsData } from './Projects/IProjectStats';
interface EmployeeTimeSheetContextType {
    projectsData: ProjectsData[];
    setProjectsData: React.Dispatch<React.SetStateAction<ProjectsData[]>>;
    isUserReportingManager: boolean;
    setIsUserReportingManager: React.Dispatch<React.SetStateAction<boolean>>;
    isUserProjectManager: boolean;
    setIsUserProjectManager: React.Dispatch<React.SetStateAction<boolean>>;
    isUserAdmin: boolean;
    setUserAdmin: React.Dispatch<React.SetStateAction<boolean>>;
    isUserProjectTeam: boolean;
    setIsUserProjectTeam: React.Dispatch<React.SetStateAction<boolean>>;
    loggedInUserDetails: any;
    setLoggedInUserDetails: React.Dispatch<React.SetStateAction<any>>;
}
export declare const EmployeeTimeSheetProvider: React.FC<{
    children: ReactNode;
}>;
export declare const useEmployeeTimeSheetContext: () => EmployeeTimeSheetContextType;
export {};
//# sourceMappingURL=EmployeeTimeSheetContext.d.ts.map