declare const styles: {
    searchContainer: string;
};
export default styles;
//# sourceMappingURL=ProjectTimeSheet.module.scss.d.ts.map