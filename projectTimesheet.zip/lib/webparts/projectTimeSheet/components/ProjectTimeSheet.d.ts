import * as React from 'react';
import type { IProjectTimeSheetProps } from './IProjectTimeSheetProps';
declare const ProjectTimeSheet: React.FC<IProjectTimeSheetProps>;
export default ProjectTimeSheet;
//# sourceMappingURL=ProjectTimeSheet.d.ts.map