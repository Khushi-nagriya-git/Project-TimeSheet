import * as React from "react";
declare const SideNavigation: (props: {
    setModuleTab: React.Dispatch<React.SetStateAction<any>>;
}) => JSX.Element;
export default SideNavigation;
//# sourceMappingURL=SideNavigation.d.ts.map