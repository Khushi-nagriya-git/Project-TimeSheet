export default function AppHeader(props: {
    userEmail: string;
    siteURL: string;
    userName: string;
}): JSX.Element;
//# sourceMappingURL=AppHeader.d.ts.map