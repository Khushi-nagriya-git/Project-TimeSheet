import { WebPartContext } from "@microsoft/sp-webpart-base";
import { JobFormData } from "./IJobFormStats";
export interface IJobFormProps {
    mode: 'add' | 'edit';
    initialData?: JobFormData;
    onSubmit: (data: JobFormData) => void;
    spHttpClient: any;
    absoluteURL: any;
    context: WebPartContext;
}
//# sourceMappingURL=IJobFormProps.d.ts.map