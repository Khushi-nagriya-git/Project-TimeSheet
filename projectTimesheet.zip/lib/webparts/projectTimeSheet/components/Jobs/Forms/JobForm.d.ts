import * as React from "react";
import { IJobFormProps } from "./IJobFormProps";
declare const FormComponent: React.FC<IJobFormProps>;
export default FormComponent;
//# sourceMappingURL=JobForm.d.ts.map