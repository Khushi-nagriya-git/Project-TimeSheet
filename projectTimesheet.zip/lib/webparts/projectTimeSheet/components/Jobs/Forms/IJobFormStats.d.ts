export interface JobAssginees {
    name: string;
    email: string;
    id: number;
    cost: number;
    estimatedHours: number;
}
export interface JobFormData {
    jobName: string;
    jobId: number;
    projectName: string;
    projectId: number;
    startDate: Date | null;
    endDate: Date | null;
    Hours: number;
    jobAssginees: JobAssginees[];
    description: string;
    billableStatus: string;
    workItem: string;
    jobStatus: string;
    attachment: any;
}
export declare const initialState: {
    jobFormData: JobFormData;
};
//# sourceMappingURL=IJobFormStats.d.ts.map