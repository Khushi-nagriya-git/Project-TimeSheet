export interface JobAssginees {
    name: string;
    cost: number;
    estimatedHours: number;
}
export interface JobsData {
    JobName: string;
    JobId: number;
    ProjectName: string;
    ProjectId: number;
    StartDate: Date | null;
    EndDate: Date | null;
    Hours: number;
    JobAssginees: JobAssginees[];
    Description: string;
    BillableStatus: string;
    WorkItem: string;
    JobStatus: string;
    Attachment: any;
}
export declare const jobsInitialState: {
    jobsData: JobsData[];
};
//# sourceMappingURL=IJobsStats.d.ts.map