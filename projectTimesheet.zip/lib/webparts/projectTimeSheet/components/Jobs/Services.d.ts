import { SPHttpClient } from "@microsoft/sp-http";
import { JobFormData } from "../Jobs/Forms/IJobFormStats";
export declare const getJobListData: (absoluteURL: string, spHttpClient: SPHttpClient, setJobsData: React.Dispatch<React.SetStateAction<any>>) => Promise<void>;
export declare const getLastJobId: (absoluteURL: string, spHttpClient: SPHttpClient) => Promise<number>;
export declare const addJobs: (data: JobFormData, absoluteURL: string, spHttpClient: SPHttpClient) => Promise<void>;
export declare const handleUploadAttachment: (itemId: number, file: File, absoluteURL: string, spHttpClient: SPHttpClient) => Promise<import("@microsoft/sp-http-base").SPHttpClientResponse>;
//# sourceMappingURL=Services.d.ts.map