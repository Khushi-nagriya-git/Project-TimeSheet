import { IProjectProps } from "../IProjectProps";
declare const MyTeam: (props: {
    spHttpClient: any;
    absoluteURL: any;
    projectProps: IProjectProps;
}) => JSX.Element;
export default MyTeam;
//# sourceMappingURL=myTeam.d.ts.map