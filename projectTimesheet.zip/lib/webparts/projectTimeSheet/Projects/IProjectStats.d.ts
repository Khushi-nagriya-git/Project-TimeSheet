export interface ProjectManager {
    name: string;
    cost: number;
}
export interface ProjectsData {
    ProjectName: string;
    ProjectId: number;
    ClientName: string;
    ProjectCost: number;
    ReportingManager: {};
    ProjectManager: ProjectManager[];
    ProjectTeam: ProjectManager[];
    Department: string;
    ProjectType: string;
    Description: string;
    Attachment: any;
    ProjectStatus: string;
}
export declare const projectsInitialState: {
    projectsData: ProjectsData[];
};
//# sourceMappingURL=IProjectStats.d.ts.map