import * as React from "react";
interface DeleteDialogBoxProps {
    open: boolean;
    handleClose: () => void;
    handleDeleteAction: () => void;
}
declare const DeleteDialogBox: React.FC<DeleteDialogBoxProps>;
export default DeleteDialogBox;
//# sourceMappingURL=DeleteDialogBox.d.ts.map