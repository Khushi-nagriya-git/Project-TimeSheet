import * as React from "react";
interface CannotDeleteDialogBoxProps {
    open: boolean;
    handleClose: () => void;
}
declare const CannotDeleteDialogBox: React.FC<CannotDeleteDialogBoxProps>;
export default CannotDeleteDialogBox;
//# sourceMappingURL=CannotDeleteDialogBox.d.ts.map