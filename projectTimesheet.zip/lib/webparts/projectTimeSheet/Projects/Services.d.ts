/// <reference types="react" />
import { SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";
import { CustomFormData } from "../Projects/Forms/IFormStats";
export declare const getProjectListData: (absoluteURL: string, spHttpClient: SPHttpClient, setProjectsData: React.Dispatch<React.SetStateAction<any>>) => Promise<void>;
export declare const getLastItemId: (absoluteURL: string, spHttpClient: SPHttpClient) => Promise<number>;
export declare const addProjects: (data: CustomFormData, absoluteURL: string, spHttpClient: SPHttpClient) => Promise<void>;
export declare const handleUploadAttachment: (itemId: number, file: File, absoluteURL: string, spHttpClient: SPHttpClient) => Promise<SPHttpClientResponse>;
export declare const deleteProject: (absoluteURL: string, spHttpClient: SPHttpClient, projectId: number, setProjectsData: React.Dispatch<React.SetStateAction<any>>) => Promise<void>;
export declare function updateUserRecords(spHttpClient: SPHttpClient, absoluteURL: string, projectId: number, updateformData: CustomFormData, setProjectsData: React.Dispatch<React.SetStateAction<any>>, setCurrentData: React.Dispatch<React.SetStateAction<any>>): Promise<void>;
//# sourceMappingURL=Services.d.ts.map