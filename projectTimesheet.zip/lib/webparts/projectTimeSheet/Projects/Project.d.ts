import * as React from "react";
import { IProjectProps } from "./IProjectProps";
declare const Project: React.FC<IProjectProps>;
export default Project;
//# sourceMappingURL=Project.d.ts.map