import * as React from "react";
import { IFormProps } from "./IFormProps";
declare const FormComponent: React.FC<IFormProps>;
export default FormComponent;
//# sourceMappingURL=Form.d.ts.map