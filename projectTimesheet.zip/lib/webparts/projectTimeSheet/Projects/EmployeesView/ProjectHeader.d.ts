import * as React from 'react';
interface ProjectHeaderProps {
    onProjectFilterChange: (selectedValues: string[]) => void;
    onProjectStatusChange: (selectedValues: string[]) => void;
    setSearchQuery: React.Dispatch<React.SetStateAction<string>>;
    setFilteredProjects: React.Dispatch<React.SetStateAction<any>>;
    filteredProjects: any;
    searchQuery: string;
    projectsData: any;
}
declare const ProjectHeader: React.FC<ProjectHeaderProps>;
export default ProjectHeader;
//# sourceMappingURL=ProjectHeader.d.ts.map