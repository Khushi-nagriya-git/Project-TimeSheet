import { IProjectProps } from "../IProjectProps";
declare const Row: (props: {
    row: ReturnType<any>;
    projectProps: IProjectProps;
    handleDeleteIconClick: any;
    handleEditIconClick: any;
    topNavigationMode: any;
}) => JSX.Element;
export default Row;
//# sourceMappingURL=TableRows.d.ts.map