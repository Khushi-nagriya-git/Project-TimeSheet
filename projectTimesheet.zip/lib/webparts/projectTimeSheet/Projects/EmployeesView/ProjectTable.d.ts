import * as React from "react";
declare const ProjectTable: (props: {
    projectsData: any;
    projectProps: any;
    jobsData: any;
    selectedProjectName: any;
    selectedStatusName: any;
    searchQuery: any;
    filteredProjects: any;
    topNavigationMode: any;
    setAddFormOpen: React.Dispatch<React.SetStateAction<any>>;
    setDeletedProjectId: React.Dispatch<React.SetStateAction<any>>;
    setIsOpen: React.Dispatch<React.SetStateAction<any>>;
    setMode: React.Dispatch<React.SetStateAction<any>>;
    setEditProjectId: React.Dispatch<React.SetStateAction<any>>;
    setDeleteAlert: React.Dispatch<React.SetStateAction<any>>;
    setCurrentData: React.Dispatch<React.SetStateAction<any>>;
    setPeoplePickerDefaultManager: React.Dispatch<React.SetStateAction<any>>;
    setPeoplePickerDefaultReportingManager: React.Dispatch<React.SetStateAction<any>>;
    setPeoplePickerDefaultTeam: React.Dispatch<React.SetStateAction<any>>;
    setFilteredProjects: React.Dispatch<React.SetStateAction<any>>;
}) => JSX.Element;
export default ProjectTable;
//# sourceMappingURL=ProjectTable.d.ts.map