import * as React from "react";
import { Button, Box } from "@mui/material";
import { styled } from "@mui/system";

const Header = styled("div")({
  height: "calc(10% - 15px)", // 10% of the height minus the margin
  width: "100%",
  marginBottom: "10px", // Margin between header and content
  backgroundColor: "#F9F9F9",
  boxSizing: "border-box",
  padding: "8px",
  borderRadius: "5px",
  boxShadow: "0 4px 8px #9D9D9D",
  //outline: "1px solid #9D9D9D", // Outline with the specified color
  display: "flex",
  justifyContent: "flex-start",
  alignItems: "flex-start", // Align items to the top/left side
});

const StyledButton = styled(Button)(({ theme }) => ({
  borderRadius: "5px",
  textTransform: "none",
  color: "#000",
  borderColor: "#000",
  marginRight: "10px", // Space between buttons
  "&.active": {
    backgroundColor: "#1565c0",
    color: "#fff",
    borderColor: "#55ADFF",
  },
}));

const TopNavigation = (props: {
  setTopNavigationState : React.Dispatch<React.SetStateAction<any>>;
  setTopNavigationMode : React.Dispatch<React.SetStateAction<any>>;
}) => {
  const [activeTab, setActiveTab] = React.useState("myData");

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    props.setTopNavigationState(tab);
    if(tab === "myData"){
      props.setTopNavigationMode("Employee");
    }
  };

  return (
    <Box>
      <Header>
        <StyledButton
          className={activeTab === "myData" ? "active" : ""}
          onClick={() => handleTabChange("myData")}
        >
          My Data
        </StyledButton>
        <StyledButton
          className={activeTab === "team" ? "active" : ""}
          onClick={() => handleTabChange("team")}
        >
          Team
        </StyledButton>
      </Header>
      {/* Content related to the active tab goes here */}
    </Box>
  );
};

export default TopNavigation;
