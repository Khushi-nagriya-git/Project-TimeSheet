import * as React from "react";
import { Box, Button } from "@mui/material";
import { styled } from "@mui/system";

const SidebarContainer = styled("div")({
  borderRadius: "5px",
  marginTop: "10px",
  marginLeft: "10px",
  background: "#F9F9F9",
  display: "flex",
  flexDirection: "column",
  alignItems: "flex-start",
  justifyContent: "flex-start",
  padding: "15px",
  width: "13%",
  height: "435px",
  boxShadow: "0 4px 8px #9D9D9D"
});

const StyledButton = styled(Button)(({ theme }) => ({
  borderRadius: "5px",
  textTransform: "none",
  color: "#000",
  borderColor: "#000",
  marginBottom: "10px", // Space between buttons
  width: "100%", // Full width for buttons
  minWidth: "180px", // Minimum width for buttons
  height: "50px", // Increased height for buttons
  display: "flex",
  alignItems: "center", // Align content vertically centered
  paddingLeft: "0px", // Add padding for content alignment
  justifyContent: "flex-start", // Align content to the left start
  "&.active": {
    backgroundColor: "#1565c0",
    color: "#fff",
    borderColor: "#55ADFF",
  },
}));



const SideNavigation= (props: {setModuleTab: React.Dispatch<React.SetStateAction<any>>}) => {
  const [activeTab, setActiveTab] = React.useState("Projects");

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    if (tab === "TimeLogs") {
      props.setModuleTab("TimeLogs");
    } else if (tab === "TimeSheets") {
      props.setModuleTab("TimeSheets")
    } else if (tab === "Jobs") {
      props.setModuleTab("Jobs")
    } else if (tab === "Projects") {
      props.setModuleTab("Projects")
    }
  };

  return (
    <SidebarContainer>
    <Box>
      <StyledButton
        className={activeTab === "TimeLogs" ? "active" : ""}
        onClick={() => handleTabChange("TimeLogs")}
      >
        <img
          src={
            activeTab === "TimeLogs"
              ? require("../../assets/clockwhite.png")
              : require("../../assets/clockgray.png")
          }
          alt="Time Logs"
          style={{
            marginRight: "10px",
            height: "25px",
            width: "25px",
            marginLeft:"10px"
          }}
        />
        Time Logs
      </StyledButton>
      <StyledButton
        className={activeTab === "TimeSheets" ? "active" : ""}
        onClick={() => handleTabChange("TimeSheets")}
      >
        <img
          src={
            activeTab === "TimeSheets"
              ? require("../../assets/tablewhite.png")
              : require("../../assets/tablegray.png")
          }
          alt="TimeSheets"
          style={{
            marginRight: "10px",
            height: "25px",
            width: "25px",
            marginLeft:"10px"

          }}
        />
        TimeSheets
      </StyledButton>
      <StyledButton
        className={activeTab === "Jobs" ? "active" : ""}
        onClick={() => handleTabChange("Jobs")}
      >
        <img
          src={
            activeTab === "Jobs"
              ? require("../../assets/jobwhite.png")
              : require("../../assets/jobgray.png")
          }
          alt="Jobs"
          style={{
            marginRight: "10px",
            height: "25px",
            width: "25px",
            marginLeft:"10px"

          }}
        />
        Jobs
      </StyledButton>
      <StyledButton
        className={activeTab === "Projects" ? "active" : ""}
        onClick={() => handleTabChange("Projects")}
      >
        <img
          src={
            activeTab === "Projects"
              ? require("../../assets/projectwhite.png")
              : require("../../assets/projectgray.png")
          }
          alt="Projects"
          style={{
            marginRight: "10px",
            height: "25px",
            width: "25px",
            marginLeft:"10px"

          }}
        />
        Project
      </StyledButton>
    </Box>
  </SidebarContainer>
  );
};

export default SideNavigation;
