import * as React from "react";
import { useState, useEffect, ChangeEvent, FormEvent } from "react";
import { initialState, JobFormData, JobAssginees } from "./IJobFormStats";
import { IJobFormProps } from "./IJobFormProps";
import { Stack, TextField, PrimaryButton } from "@fluentui/react";
import {
  PeoplePicker,
  PrincipalType,
} from "@pnp/spfx-controls-react/lib/PeoplePicker";
import {
  Dropdown,
  Field,
  makeStyles,
  Option,
  Textarea,
  useId,
} from "@fluentui/react-components";
import { DatePicker, DayOfWeek } from '@fluentui/react';
import { getProjectListData } from '../../../Projects/Services';
import { ProjectsData, projectsInitialState } from "../../../Projects/IProjectStats";

const useStyles = makeStyles({
  root: {
    display: "grid",
    gridTemplateRows: "repeat(1fr)",
    justifyItems: "start",
    gap: "2px",
    maxWidth: "400px",
  },
});

const FormComponent: React.FC<IJobFormProps> = (props: any) => {
  const [jobFormData, setjobFormData] = useState<JobFormData>(
    initialState.jobFormData
  );
  const [showCostFields, setShowCostFields] = useState(false);
  const [projectsData, setProjectsData] = useState<ProjectsData[]>(projectsInitialState.projectsData);
  const [showCostFieldsForProjectTeam, setShowCostFieldsForProjectTeam] =
    useState(false);
  const dropdownId = useId("dropdown-default");
  const options = ["Fixed Cost", "Resource Based"];
  const styles = useStyles();

  useEffect(() => {
    if (props.mode === "edit" && props.initialData) {
      setjobFormData(props.initialData);
    }
  }, [props.mode, props.initialData]);

  useEffect(() => {
    getProjectListData(props.absoluteURL, props.spHttpClient,setProjectsData)
  }, []);

  //   useEffect(() => {
  //     if (!showCostFields) {
  //       const updatedProjectManagers = jobFormData.projectManager.map((manager:any) => ({
  //         ...manager,
  //         cost: 0,
  //       }));
  //       setFormData((prevState) => ({
  //         ...prevState,
  //         projectManager: updatedProjectManagers,
  //       }));
  //     }

  //     if (!showCostFieldsForProjectTeam) {
  //       const updatedProjectTeam = formData.projectTeam.map((teamMember) => ({
  //         ...teamMember,
  //         cost: 0,
  //       }));
  //       setFormData((prevState) => ({
  //         ...prevState,
  //         projectTeam: updatedProjectTeam,
  //       }));
  //     }
  //   }, [showCostFields, showCostFieldsForProjectTeam]);

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setjobFormData({
      ...jobFormData,
      [name]: name === "projectCost" ? Number(value) : value,
    });
  };


  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    props.onSubmit(jobFormData);
  };

 

  const getPeoplePickerJobAssignees = (items: any[]) => {
    if (items && items.length > 0) {
      const updatedJobAssginees: JobAssginees[] = items.map((item) => ({
        name: item.text,
        email: item.loginName.split("|")[2],
        id: item.id,
        cost: 0,
        estimatedHours:0
      }));
      setjobFormData({
        ...jobFormData,
        jobAssginees: updatedJobAssginees,
      });
    } else {
      setjobFormData({
        ...jobFormData,
        jobAssginees: [],
      });
      setShowCostFields(false);
    }
  };

  

  const handleCostChange = (
    index: number,
    e: ChangeEvent<HTMLInputElement>
  ) => {
    const { value } = e.target;
    const updatedProjectManagers = [...jobFormData.jobAssginees];
    updatedProjectManagers[index].cost = showCostFields ? Number(value) : 0;
    setjobFormData({
      ...jobFormData,
      jobAssginees: updatedProjectManagers,
    });
  };

  const handleCostChangeForProjecTeam = (
    index: number,
    e: ChangeEvent<HTMLInputElement>
  ) => {
    const { value } = e.target;
    const updatedjobAssginees = [...jobFormData.jobAssginees];
    updatedjobAssginees[index].cost = showCostFieldsForProjectTeam
      ? Number(value)
      : 0;
    setjobFormData({
      ...jobFormData,
      jobAssginees: updatedjobAssginees,
    });
  };

  const dateHandleChange = (event: any) => {
    const { name, value } = event.target;
    setjobFormData({
      ...jobFormData,
      [name]: value,
    });
  };

  const handleChangeAttchment = (e: FormEvent<HTMLInputElement>) => {
    const target = e.target as HTMLInputElement & {
      files: FileList;
    };
    const selectedFile = target.files[0];
    setjobFormData({
      ...jobFormData,
      attachment: selectedFile,
    });
  };

  const handleChangeDropDown = (e: ChangeEvent<HTMLSelectElement>) => {
    setjobFormData({
      ...jobFormData,
      projectName: e.target.value, // Changed from e.target.innerText to e.target.value
    });
  };

  return (
    <Stack as="form" onSubmit={handleSubmit} tokens={{ childrenGap: 15 }}>
      <h3>Job Form</h3>
      <TextField
        label="Job Name"
        name="jobName"
        value={jobFormData.jobName}
        onChange={handleChange}
        required
      />

      <TextField
        label="Project Name"
        name="projectName"
        value={jobFormData.projectName}
        onChange={handleChange}
      />

<div className={styles.root}>
    <label id={dropdownId}>Project Name</label>
    <select
      aria-labelledby={dropdownId}
      placeholder="Select project type"
      onChange={handleChangeDropDown}
    >
      <option value="" disabled selected>Select project type</option>
      {projectsData.map((project: any, index: any) => (
        <option key={index} value={project.ProjectName}>
          {project.ProjectName}
        </option>
      ))}
    </select>
  </div>
<DatePicker
        label="Start Date"
        value={jobFormData.startDate || undefined}
        onSelectDate={(date: any) =>
            dateHandleChange({ target: { name: "endDate", value: date } })
          }
          isRequired={true}
        firstDayOfWeek={DayOfWeek.Sunday}
        placeholder="Select a date..."
        ariaLabel="Select a date"
      />

      <DatePicker
        label="End Date"
        value={jobFormData.endDate || undefined}
        onSelectDate={(date: any) =>
          dateHandleChange({ target: { name: "endDate", value: date } })
        }
        isRequired={true}
        firstDayOfWeek={DayOfWeek.Sunday}
        placeholder="Select a start date..."
        ariaLabel="Select a start date"
      />

      <TextField
        label="Job Hours"
        type="number"
        name="Hours"
        value={jobFormData.Hours.toString()}
        onChange={handleChange}
      />

      <PeoplePicker
        context={props.context as any}
        titleText="Assigneed To"
        personSelectionLimit={100}
        required={true}
        disabled={false}
        showtooltip
        ensureUser={true}
        onChange={getPeoplePickerJobAssignees}
        resolveDelay={300}
        principalTypes={[PrincipalType.User]}
        groupName={""}
      />
      {showCostFields &&
        jobFormData.jobAssginees.map((manager: any, index: any) => (
          <TextField
            key={index}
            label={`Cost for ${manager.name}`}
            type="number"
            value={manager.cost.toString()}
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              handleCostChange(index, e)
            }
          />
        ))}

      <Field label="Description">
        <Textarea
          {...props}
          name="description"
          value={jobFormData.description}
          onChange={handleChange}
        />
      </Field>

      <TextField
        label="Billable Status"
        name="billableStatus"
        value={jobFormData.billableStatus}
        onChange={handleChange}
        required
      />

      <Field label="Work Item">
        <Textarea
          {...props}
          name="workItem"
          value={jobFormData.workItem}
          onChange={handleChange}
        />
      </Field>

      <Field label="Attachment">
        <input
          type="file"
          name="Attachment"
          onChange={handleChangeAttchment}
        ></input>
      </Field>

      <PrimaryButton type="submit">
        {props.mode === "edit" ? "Update" : "Add"}
      </PrimaryButton>
    </Stack>
  );
};

export default FormComponent;
