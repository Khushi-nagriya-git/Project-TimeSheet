export interface JobAssginees {
    name: string;
    email:string;
    id:number;
    cost: number;
    estimatedHours:number;
  }

export interface JobFormData {
    jobName: string;
    jobId: number;
    projectName: string;
    projectId: number;
    startDate: Date | null;
    endDate: Date | null;
    Hours: number;
    jobAssginees:JobAssginees[];
    description:string;
    billableStatus:string;
    workItem: string;
    jobStatus: string;
    attachment:any;
}

const initialJobFormData: JobFormData = {
    jobName: "",
    jobId: 0,
    projectName: "",
    projectId: 0,
    startDate: null,
    endDate: null,
    Hours: 0,
    jobAssginees:[],
    description: "",
    billableStatus:"",
    workItem: "",
    jobStatus: "",
    attachment:undefined
};

export const initialState = {
    jobFormData: initialJobFormData
};
