import { SPHttpClient } from "@microsoft/sp-http";
import { JobFormData } from "../Jobs/Forms/IJobFormStats";

interface ISPHttpClientOptions {
  headers?: { [key: string]: string };
  body?: any;
}

export const getJobListData = async (
  absoluteURL: string,
  spHttpClient: SPHttpClient,
  setJobsData: React.Dispatch<React.SetStateAction<any>>,
) => {
  try {
      const response = await spHttpClient.get(
          `${absoluteURL}/_api/web/lists/GetByTitle('Jobs')/items?$select=JobName,JobId,ProjectName,ProjectId,Hours,AssignedTo,StartDate,EndDate,Description,JobStatus,BillableStatus,Attachments,WorkItem`,
          SPHttpClient.configurations.v1
      );
      if (response.ok) {
        const data = await response.json();
        if (data.value.length > 0) {
            setJobsData(data.value);
          console.log("Jobs data", data.value);
        }
      } else {
          console.log("Please enter the correct name of the list in the property pane.");
      }
  } catch (error) {
      console.log("Error fetching data:", error);
  }
};

export const getLastJobId = async (absoluteURL: string, spHttpClient: SPHttpClient): Promise<number> => {
  const requestURL = `${absoluteURL}/_api/web/lists/getbytitle('Jobs')/items?$orderby=ID desc&$top=1`;
  const response = await spHttpClient.get(requestURL, SPHttpClient.configurations.v1, {
    headers: {
      Accept: "application/json;odata=nometadata",
      "odata-version": "",
    },
  });
  if (!response.ok) {
    console.error("Error fetching the last item");
    return 0;
  }
  const data = await response.json();
  let id = 0;
  if (data.value.length > 0) {
    id = data.value[0].JobId + 1;
  } else {
    id = 101;
  }
  return id;
};

export const addJobs = async (
  data: JobFormData,
  absoluteURL: string,
  spHttpClient: SPHttpClient
) => {
  const newJobId = await getLastJobId(absoluteURL, spHttpClient);
  const listItemData = {
    JobName: data.jobName,
    JobId:newJobId,
    ProjectName: data.projectName,
    ProjectId: data.projectId,
    StartDate: data.startDate,
    EndDate: data.endDate,
    Hours: data.Hours,
    AssignedTo: JSON.stringify(data.jobAssginees),
    Description: data.description,
    BillableStatus: data.billableStatus,
    WorkItem: data.workItem,
    JobStatus: data.jobStatus,
    Attachments: data.attachment
  };

  const requestURL = `${absoluteURL}/_api/web/lists/getbytitle('Jobs')/items`;
  const response = await spHttpClient.post(requestURL, SPHttpClient.configurations.v1, {
    headers: {
      Accept: "application/json;odata=nometadata",
      "Content-type": "application/json;odata=nometadata",
      "odata-version": "",
    },
    body: JSON.stringify(listItemData),
  });
  if (!response.ok) {
    console.error("Error adding jobs records");
    return;
  }

  const item: any = await response.json();
  if (data.attachment) {
    const attachmentResponse = await handleUploadAttachment(item.ID, data.attachment, absoluteURL, spHttpClient);
    if (!attachmentResponse.ok) {
      console.error("Error uploading attachment");
      return;
    }
  }
  alert("Job added");
};

export const handleUploadAttachment = async (
  itemId: number,
  file: File,
  absoluteURL: string,
  spHttpClient: SPHttpClient
) => {
  const attachmentURL = `${absoluteURL}/_api/web/lists/getbytitle('Jobs')/items(${itemId})/AttachmentFiles/add(FileName='${file.name}')`;
  const options: ISPHttpClientOptions = {
    body: file,
    headers: {
      Accept: "application/json;odata=nometadata",
      "Content-type": file.type,
      "odata-version": "",
    },
  };

  return spHttpClient.post(attachmentURL, SPHttpClient.configurations.v1, options);
};
