export interface JobAssginees {
    name: string;
    cost: number;
    estimatedHours:number;
  }

export interface JobsData {
    JobName: string;
    JobId: number;
    ProjectName: string;
    ProjectId: number;
    StartDate: Date | null;
    EndDate: Date | null;
    Hours: number;
    JobAssginees:JobAssginees[];
    Description:string;
    BillableStatus:string;
    WorkItem: string;
    JobStatus: string;
    Attachment:any;
}

const initialJobsData: JobsData = {
    JobName: "",
    JobId: 0,
    ProjectName: "",
    ProjectId: 0,
    StartDate: null,
    EndDate: null,
    Hours: 0,
    JobAssginees:[],
    Description: "",
    BillableStatus:"",
    WorkItem: "",
    JobStatus: "",
    Attachment:undefined
};


export const jobsInitialState = {
    jobsData: [initialJobsData]
};
