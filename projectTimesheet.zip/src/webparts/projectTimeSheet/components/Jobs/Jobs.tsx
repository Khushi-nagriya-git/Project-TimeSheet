import * as React from "react";
import { useState, useEffect } from "react";
import FormComponent from '../Jobs/Forms/JobForm'; 
import { initialState, JobFormData } from "../Jobs/Forms/IJobFormStats";
import { IJobsProps } from "./IJobsProps";
import {JobsData, jobsInitialState} from './IJobsStats';
import { addJobs , getJobListData} from './Services'

const Jobs: React.FC<IJobsProps> = (props: IJobsProps) => {
  const [mode, setMode] = useState<'add' | 'edit'>('add');
  const [currentData, setCurrentData] = useState<JobFormData>(initialState.jobFormData);
  const [jobsData, setJobsData] = useState<JobsData[]>(jobsInitialState.jobsData);

  useEffect(() => {
    getJobListData(props.absoluteURL, props.spHttpClient,setJobsData)
  }, []);

  const handleSubmit = (data: JobFormData) => {
    if (mode === 'add') {
        addJobs(data, props.absoluteURL, props.spHttpClient);
    } else if (mode === 'edit') {
      handleUpdate(data);
    }
    setMode('add');
    setCurrentData(initialState.jobFormData);
  };

  const handleUpdate = (data: JobFormData) => {
    // Update data handling logic here
    console.log('Updating data:', data);
  };

  const handleEdit = (data: JobFormData) => {
    setMode('edit');
    setCurrentData(data);
  };

  return (
    <div>
      <h1>{mode === 'edit' ? 'Edit Item' : 'Add Item'}</h1>
      <FormComponent mode={mode} initialData={currentData ?? undefined} onSubmit={handleSubmit} spHttpClient={props.spHttpClient} absoluteURL={props.absoluteURL} context={props.context} />
      <button onClick={() => handleEdit({
          jobName: "",
          jobId: 0,
          projectName: "",
          projectId: 0,
          startDate: null,
          endDate: null,
          Hours: 0,
          jobAssginees:[],
          description: "",
          billableStatus:"",
          workItem: "",
          jobStatus: "",
          attachment:undefined
      })}>
        Edit John Doe
      </button>
    </div>
  );
};

export default Jobs;
