import * as React from "react";
import { useState, useEffect } from "react";
import FormComponent from "./Forms/Form";
import { initialState, CustomFormData } from "../Projects/Forms/IFormStats";
import { JobsData, jobsInitialState } from "../components/Jobs/IJobsStats";
import DeleteDialogBoxProps from "../Projects/DialogBoxs/DeleteDialogBox";
import { IProjectProps } from "./IProjectProps";
import { addProjects, getProjectListData, deleteProject, updateUserRecords } from "./Services";
import { getJobListData } from "../../projectTimeSheet/components/Jobs/Services";
import { ProjectsData, projectsInitialState } from "./IProjectStats";
import { styled } from "@mui/system";
import TopNavigation from "../../projectTimeSheet/components/Navigation/TopNavigation";
import { Button, Grid } from "@mui/material";
import ProjectHeader from "./EmployeesView/ProjectHeader";
import ProjectTable from "./EmployeesView/ProjectTable";
import Alert from "@mui/material/Alert";
import DepartmentView from "./DepartmentView/DepartmentView";
import CannotDeleteDialogBox from "./DialogBoxs/CannotDeleteDialogBox";
import MyTeam from "./MyTeam/myTeam";

const FullHeightGrid = styled(Grid)({
  height: "100%", 
  boxSizing: "border-box",
});

const MainContainer = styled("div")({
  width: "100%", 
  height: "100%", 
  padding: "16px",
  boxSizing: "border-box",
});

const NavigationLinks = styled("div")({
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  marginBottom: "10px",
});

const NavigationLinksForTeams = styled("div")({
  display: "flex",
  alignItems: "center",
  justifyContent: "left",
  marginBottom: "2px",
});

const NavLink = styled(Button)(({ theme }) => ({
  textTransform: "none",
  color: "#000",
  borderBottom: "3px solid transparent",
  marginRight: "20px",
  "&.active": {
    color: "#000",
    borderBottom: "3px solid #1565c0",
  },
}));

const Content = styled("div")({
  height: "395px",
  backgroundColor: "#F9F9F9",
  boxSizing: "border-box",
  padding: "13px",
  borderRadius: "5px",
  background: "#F9F9F9",
  boxShadow: "0 4px 8px #9D9D9D",
});

const Project: React.FC<IProjectProps> = (props: IProjectProps) => {
  const [mode, setMode] = useState<"add" | "edit">("add");
  const [myDataActiveLink, setMyDataActiveLink] = useState<string>("Employee");
  const [teamActiveLink, setTeamActiveLink] = useState<string>("ProjectMembers");
  const [isOpen, setIsOpen] = useState(false);
  const [deleteAlert, setDeleteAlert] = useState(false);
  const [addFormOpen, setAddFormOpen] = useState(false);
  const [deletedProjectId, setDeletedProjectId] = useState<number>(0);
  const [editProjectId , setEditProjectId ]= useState<number>(0);
  const [currentData, setCurrentData] = useState<CustomFormData>(initialState.formData);
  const [projectsData, setProjectsData] = useState<ProjectsData[]>(projectsInitialState.projectsData);
  const [jobsData, setJobsData] = useState<JobsData[]>(jobsInitialState.jobsData);
  const [deleteSuccessfullyAlert, setDeleteSuccessfullyAlert] = useState(false);
  const [addSuccessFullyAlert, setAddSuccessFullyAlert] = useState(false);
  const [editSuccessFullyAlert, setEditSuccessFullyAlert] = useState(false);
  const [selectedProjectName, setSelectedProjectName] = useState<string[]>([]);
  const [selectedStatusName, setSelectedStatusName] = useState<string[]>([]);
  const [peoplePickerDefaultManager, setPeoplePickerDefaultManager] = useState('');
  const [peoplePickerDefaultReportingManager, setPeoplePickerDefaultReportingManager] = useState('');
  const [peoplePickerDefaultTeam, setPeoplePickerDefaultTeam] = useState('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filteredProjects, setFilteredProjects] = useState<ProjectsData[]>(projectsInitialState.projectsData);
  const [topNavigationState, setTopNavigationState] = useState<string>("myData");
  const [topNavigationMode, setTopNavigationMode] = useState<string>("Employee");

  useEffect(() => {
    getProjectListData(props.absoluteURL, props.spHttpClient, setProjectsData);
    getJobListData(props.absoluteURL, props.spHttpClient, setJobsData);
  }, []);

  useEffect(() => {
    if (deleteSuccessfullyAlert) {
      const timer = setTimeout(() => {
        setDeleteSuccessfullyAlert(false);
      }, 5000); 
      return () => clearTimeout(timer);
    }
  }, [deleteSuccessfullyAlert]);

  useEffect(() => {
    if (addSuccessFullyAlert) {
      const timer = setTimeout(() => {
        setAddSuccessFullyAlert(false);
      }, 5000); // 5000 milliseconds = 5 seconds
      return () => clearTimeout(timer);
    }
    if (editSuccessFullyAlert) {
      const timer = setTimeout(() => {
        setEditSuccessFullyAlert(false);
      }, 5000); // 5000 milliseconds = 5 seconds
      return () => clearTimeout(timer);
    }
  }, [addSuccessFullyAlert ,editSuccessFullyAlert ]);

  const handleSubmit = async (data: CustomFormData) => {
    if (mode === "add") {
      await addProjects(data, props.absoluteURL, props.spHttpClient);
      setAddFormOpen(false);
      setAddSuccessFullyAlert(true);
      await  getProjectListData(props.absoluteURL, props.spHttpClient, setProjectsData);
    } else if (mode === "edit") {
      updateUserRecords(props.spHttpClient,props.absoluteURL,editProjectId,data,setProjectsData,setCurrentData)
      setAddFormOpen(false);
      setEditSuccessFullyAlert(true);
      setCurrentData(initialState.formData);
    }
    setMode("add");
    setCurrentData(initialState.formData);
  };

  const handleAddProject = () => {
    setAddFormOpen(true);
    setMode("add");
  };

  const handleDelete = async () => {
    await deleteProject(
      props.absoluteURL,
      props.spHttpClient,
      deletedProjectId,
      setProjectsData,
    );
    setIsOpen(false);
    setDeleteSuccessfullyAlert(true);
  };

  const handleTabChange = (tab: string) => {
    setSelectedProjectName([]);
    setSelectedStatusName([]);
    setSearchQuery('');
    setMyDataActiveLink(tab);
    setTopNavigationMode(tab);
  };

  const handleTeamTabChange = (tab: string) => {
    setTeamActiveLink(tab);
    setTopNavigationMode(tab);
  };

  const onProjectFilterChange = (projectName: string[]) =>{
    setSelectedProjectName(projectName);
  };

  const onProjectStatusChange = (status: string[]) =>{
    setSelectedStatusName(status);
  };

  return (
    <div>
      <FullHeightGrid container>
        <FullHeightGrid
          item
          style={{ display: "flex", height: "100%", width: "100%" }}
        >     
          <MainContainer>
            <TopNavigation setTopNavigationState={setTopNavigationState} setTopNavigationMode={setTopNavigationMode}/>
            {topNavigationState === "myData" && (
                <Content>
                <NavigationLinks>
                  <NavLink
                    className={myDataActiveLink === "Employee" ? "active" : ""}
                    onClick={() => handleTabChange("Employee")}
                  >
                    Employee
                  </NavLink>
                  <NavLink
                    className={myDataActiveLink === "Department" ? "active" : ""}
                    onClick={() => handleTabChange("Department")}
                  >
                    Department
                  </NavLink>
  
                  <Grid item sx={{ marginLeft: "auto", marginBottom: "10px" }}>
                    <Button
                      variant="contained"
                      onClick={handleAddProject}
                      sx={{
                        backgroundColor: "#1565c0",
                        borderRadius: "5px",
                        width: "120px",
                        height: "35px",
                        fontSize: "12px",
                      }}
                    >
                      Add Project
                    </Button>
                  </Grid>
                </NavigationLinks>
  
                {myDataActiveLink === "Employee" && (
                  <>
                    <ProjectHeader projectsData={projectsData} onProjectFilterChange = {onProjectFilterChange} onProjectStatusChange = {onProjectStatusChange}  setSearchQuery={setSearchQuery} searchQuery={searchQuery}   setFilteredProjects = {setFilteredProjects} filteredProjects = {filteredProjects}></ProjectHeader>
                    <ProjectTable
                      projectsData={projectsData}
                      selectedProjectName={selectedProjectName}
                      selectedStatusName={selectedStatusName}
                      projectProps={props}
                      jobsData={jobsData}
                      setIsOpen={setIsOpen}
                      setDeletedProjectId={setDeletedProjectId}
                      setEditProjectId={setEditProjectId}
                      setDeleteAlert={setDeleteAlert}
                      setMode={setMode}
                      setAddFormOpen={setAddFormOpen}
                      setCurrentData={setCurrentData}
                      setPeoplePickerDefaultManager={setPeoplePickerDefaultManager}
                      setPeoplePickerDefaultReportingManager={setPeoplePickerDefaultReportingManager}
                      setPeoplePickerDefaultTeam={setPeoplePickerDefaultTeam}  
                      searchQuery={searchQuery}
                      setFilteredProjects = {setFilteredProjects}
                      filteredProjects = {filteredProjects}
                      topNavigationMode = {topNavigationMode}
                      ></ProjectTable>
                  </>
                )}
                {myDataActiveLink === "Department" && (
                  <>
                 
                    <ProjectHeader projectsData={projectsData} onProjectFilterChange = {onProjectFilterChange}  onProjectStatusChange = {onProjectStatusChange}  setSearchQuery={setSearchQuery} searchQuery={searchQuery} setFilteredProjects = {setFilteredProjects} filteredProjects = {filteredProjects}></ProjectHeader>
                    <DepartmentView projectsData={projectsData} projectProps={props} selectedProjectName={selectedProjectName} selectedStatusName={selectedStatusName}   searchQuery={searchQuery}   setFilteredProjects = {setFilteredProjects} filteredProjects = {filteredProjects}></DepartmentView>
                  </>
                )}
              </Content>
            ) }
            {topNavigationState === "team" && (
             <Content>
               <NavigationLinksForTeams>
                  <NavLink 
                    className={teamActiveLink === "ProjectMembers" ? "active" : ""}
                    onClick={() => handleTeamTabChange("ProjectMembers")}
                  >
                    Project Members
                  </NavLink>
                  <NavLink
                    className={teamActiveLink === "Project" ? "active" : ""}
                    onClick={() => handleTeamTabChange("Project")}
                  >
                    Project
                  </NavLink>

                </NavigationLinksForTeams>
                {teamActiveLink === "Project" && (
                  <>
                   <ProjectHeader projectsData={projectsData} onProjectFilterChange = {onProjectFilterChange} onProjectStatusChange = {onProjectStatusChange}  setSearchQuery={setSearchQuery} searchQuery={searchQuery}   setFilteredProjects = {setFilteredProjects} filteredProjects = {filteredProjects}></ProjectHeader>
                   <ProjectTable
                     projectsData={projectsData}
                     selectedProjectName={selectedProjectName}
                     selectedStatusName={selectedStatusName}
                     projectProps={props}
                     jobsData={jobsData}
                     setIsOpen={setIsOpen}
                     setDeletedProjectId={setDeletedProjectId}
                     setEditProjectId={setEditProjectId}
                     setDeleteAlert={setDeleteAlert}
                     setMode={setMode}
                     setAddFormOpen={setAddFormOpen}
                     setCurrentData={setCurrentData}
                     setPeoplePickerDefaultManager={setPeoplePickerDefaultManager}
                     setPeoplePickerDefaultReportingManager={setPeoplePickerDefaultReportingManager}
                     setPeoplePickerDefaultTeam={setPeoplePickerDefaultTeam}  
                     searchQuery={searchQuery}
                     setFilteredProjects = {setFilteredProjects}
                     filteredProjects = {filteredProjects}
                     topNavigationMode = {topNavigationMode}
                     ></ProjectTable>
                     </>
                )}
                {teamActiveLink === "ProjectMembers" && (
                  <MyTeam  absoluteURL = { props.absoluteURL} spHttpClient = { props.spHttpClient} projectProps={props}/>
                )}
             </Content>
            )}

          </MainContainer>
        </FullHeightGrid>
      </FullHeightGrid>
      {deleteAlert && (
        <CannotDeleteDialogBox 
        open={deleteAlert}
        handleClose = {function ():void {
          setDeleteAlert(false);
        }}
        ></CannotDeleteDialogBox>
      )}
      {isOpen && (
        <DeleteDialogBoxProps
          open={isOpen}
          handleClose={function (): void {
            setIsOpen(false);
          }}
          handleDeleteAction={handleDelete}
        />
      )}
    {deleteSuccessfullyAlert && (
        <Alert
          severity="success"
          color="warning"
          onClose={() => setDeleteSuccessfullyAlert(false)}
          sx={{
            position: "fixed",
            top: "50px",
            right: "20px",
            zIndex: 9999, 
          }}
        >
          Project has been successfully deleted!
        </Alert>
      )}
      {addSuccessFullyAlert && (
         <Alert
         severity="success"
         onClose={() => setAddSuccessFullyAlert(false)}
         sx={{
           position: "fixed",
           top: "50px", 
           right: "20px", 
           zIndex: 9999, 
         }}
       >
         Project has been successfully added!
       </Alert>
      )}
       {editSuccessFullyAlert && (
         <Alert
         severity="success"
         onClose={() => setEditSuccessFullyAlert(false)}
         sx={{
           position: "fixed",
           top: "50px", 
           right: "20px", 
           zIndex: 9999, 
         }}
       >
         Project has been successfully edited!
       </Alert>
      )}
      {addFormOpen && (
        <FormComponent
          mode={mode}
          initialData={currentData ?? undefined}
          onSubmit={handleSubmit}
          spHttpClient={props.spHttpClient}
          absoluteURL={props.absoluteURL}
          context={props.context}
          open={addFormOpen}
          setAddFormOpen={setAddFormOpen}
          peoplePickerDefaultManager = {peoplePickerDefaultManager}
          peoplePickerDefaultReportingManager = {peoplePickerDefaultReportingManager}
          peoplePickerDefaultTeam = {peoplePickerDefaultTeam}
        />
      )}
    </div>
  );
};

export default Project;
