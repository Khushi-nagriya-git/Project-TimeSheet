import Grid from "@mui/material/Grid";
import Table from "@mui/material/Table/Table";
import TableBody from "@mui/material/TableBody/TableBody";
import TableCell from "@mui/material/TableCell/TableCell";
import TableContainer from "@mui/material/TableContainer/TableContainer";
import TableHead from "@mui/material/TableHead/TableHead";
import TableRow from "@mui/material/TableRow/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel/TableSortLabel";
import Typography from "@mui/material/Typography";
import * as React from "react";
import Row from "./TableRows";
import { useState, useEffect } from "react";
import Box from "@mui/material/Box/Box";

const ProjectTable = (props: {
  projectsData: any;
  projectProps: any;
  jobsData: any;
  selectedProjectName: any;
  selectedStatusName: any;
  searchQuery: any;
  filteredProjects: any;
  topNavigationMode: any;
  setAddFormOpen: React.Dispatch<React.SetStateAction<any>>;
  setDeletedProjectId: React.Dispatch<React.SetStateAction<any>>;
  setIsOpen: React.Dispatch<React.SetStateAction<any>>;
  setMode: React.Dispatch<React.SetStateAction<any>>;
  setEditProjectId: React.Dispatch<React.SetStateAction<any>>;
  setDeleteAlert: React.Dispatch<React.SetStateAction<any>>;
  setCurrentData: React.Dispatch<React.SetStateAction<any>>;
  setPeoplePickerDefaultManager: React.Dispatch<React.SetStateAction<any>>;
  setPeoplePickerDefaultReportingManager: React.Dispatch<React.SetStateAction<any>>;
  setPeoplePickerDefaultTeam: React.Dispatch<React.SetStateAction<any>>;
  setFilteredProjects: React.Dispatch<React.SetStateAction<any>>;
}) => {
  const [orderBy, setOrderBy] = useState("ProjectName");
  const [order, setOrder] = useState<"asc" | "desc">("asc");


  useEffect(() => {
    let filteredProjects = props.projectsData;
    if (props.selectedProjectName.length > 0) {
      filteredProjects = filteredProjects.filter((project: { ProjectName: string }) =>
        props.selectedProjectName.includes(project.ProjectName)
      );
    }

    if (props.selectedStatusName.length > 0) {
      filteredProjects = filteredProjects.filter((project: { ProjectStatus: string }) =>
        props.selectedStatusName.includes(project.ProjectStatus)
      );
    }

    if (props.searchQuery.trim() !== '') {
      filteredProjects = filteredProjects.filter((project: any) => {
        return (
          project.ProjectName.toLowerCase().includes(props.searchQuery.toLowerCase()) ||
          project.ProjectStatus.toLowerCase().includes(props.searchQuery.toLowerCase())
        );
      });
    }

    props.setFilteredProjects(filteredProjects);
  }, [props.selectedProjectName, props.selectedStatusName, props.projectsData, props.searchQuery]);


  const handleRequestSort = (property: any) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleDeleteIconClick = async (projectId: number) => {
    let jobCount = 0;
    const matchingJobs = [];
    for (let i = 0; i < props.jobsData.length; i++) {
      if (props.jobsData[i].ProjectId === projectId) {
        jobCount++;
        matchingJobs.push(props.jobsData[i]);
      }
    }
    if (jobCount > 0) {
      props.setDeleteAlert(true);
    } else {
      props.setIsOpen(true);
      props.setDeletedProjectId(projectId);
    }
  };

  const handleEditIconClick = async (projectId: number) => {
    props.setMode("edit");
    props.setEditProjectId(projectId);
    const project = props.projectsData.find(
      (proj: any) => proj.ProjectId === projectId
    );
    let projectManager = project.ProjectManager ? JSON.parse(project.ProjectManager) : [];
    let reportingManager = project.ReportingManager ? JSON.parse(project.ReportingManager) : [];
    let projectTeam = project.ProjectTeam ? JSON.parse(project.ProjectTeam) : [];
    let emails = projectTeam.map((member: { email: string }) => member.email);
    console.log(projectTeam, emails)
    props.setPeoplePickerDefaultManager(projectManager.length > 0 ? projectManager[0].email : '');
    props.setPeoplePickerDefaultReportingManager(reportingManager ? reportingManager.secondaryText : '');
    props.setPeoplePickerDefaultTeam(emails.length > 0 ? emails : []);

    props.setCurrentData({
      projectName: project.ProjectName,
      clientName: project.ClientName,
      projectType: project.ProjectType,
      department: project.DepartmentsORTeam,
      projectTeam: projectTeam,
      projectManager: projectManager,
      projectStatus: project.ProjectStatus,
      projectCost: project.ProjectCost,
      attachment: project.Attachment,
      description: project.Description,
    });
    props.setAddFormOpen(true);
  };

  function createData(
    projectId: number,
    projectName: string,
    projectManager: string,
    projectManagerEmail: string,
    status: string
  ) {
    const matchingJobs = [];
    for (let i = 0; i < props.jobsData.length; i++) {
      if (props.jobsData[i].ProjectId === projectId) {
        matchingJobs.push(props.jobsData[i]);
      }
    }
    return {
      projectId,
      projectName,
      projectManager,
      projectManagerEmail,
      status,
      history: matchingJobs,
    };
  }

  return (
    <div style={{ overflowY: 'auto', height: "240px", marginTop: "-15px" }}>
      <Grid item xs={12}>
        <div style={{ height: "100%", overflow: "auto" }}>
          <TableContainer>
            <Table aria-label="collapsible table" sx={{fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"}}>
              <TableHead>
                <TableRow sx={{ height: "40px", background: "#f3f2f1" }}>
                  <TableCell />
                  <TableCell
                    sx={{
                      padding: "4px 16px",
                      fontWeight: "600",
                      width: "13%",
                      position: "sticky",
                      top: 0,
                      backgroundColor: "#f3f2f1",
                      zIndex: 1,
                      //color:"#323130",
                      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                    }}
                  >
                    <TableSortLabel
                      active={orderBy === "EmployeeName"}
                      direction={orderBy === "EmployeeName" ? order : "asc"}
                      onClick={() => handleRequestSort("ProjectId")}
                    >
                      Project Id
                    </TableSortLabel>
                  </TableCell>
                  <TableCell
                    sx={{
                      padding: "4px 16px",
                      fontWeight: "600",
                      width: "20%",
                      position: "sticky",
                      top: 0,
                      backgroundColor: "#f3f2f1",
                      zIndex: 1,
                      //color:"#323130",
                      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                    }}
                    align="left"
                  >
                    Project Name
                  </TableCell>
                  <TableCell
                    sx={{
                      padding: "4px 16px",
                      fontWeight: "600",
                      width: "23%",
                      position: "sticky",
                      top: 0,
                      backgroundColor: "#f3f2f1",
                      zIndex: 1,
                      //color:"#323130",
                      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                    }}
                    align="left"
                  >
                    Project Manager
                  </TableCell>
                  <TableCell
                    sx={{
                      padding: "4px 16px",
                      fontWeight: "600",
                      width: "20%",
                      position: "sticky",
                      top: 0,
                      backgroundColor: "#f3f2f1",
                      zIndex: 1,
                      //color:"#323130",
                      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                    }}
                    align="left"
                  >
                    Status
                  </TableCell>
                  <TableCell
                    sx={{
                      padding: "4px 16px",
                      fontWeight: "600",
                      width: "10%",
                      position: "sticky",
                      top: 0,
                      backgroundColor: "#f3f2f1",
                      zIndex: 1,
                     // color:"#323130",
                      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                    }}
                    align="left"
                  >
                    Jobs
                  </TableCell>
                  {props.topNavigationMode === "Employee" && (
                    <TableCell
                      sx={{
                        padding: "4px 16px",
                        fontWeight: "600",
                        width: "24%",
                        position: "sticky",
                        top: 0,
                        backgroundColor: "#f3f2f1",
                        zIndex: 1,
                      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                     // color:"#323130"
                      }}
                      align="left"
                    >
                      Actions
                    </TableCell>
                  )}
                </TableRow>
              </TableHead>
              <TableBody>
                {props.filteredProjects.length > 0 ? (
                  props.filteredProjects.map((row: any) => {
                    let projectManagerName: any = "-";
                    let projectManagerEmail: any = "";
                    try {
                      const projectManager = row?.ProjectManager
                        ? JSON.parse(row.ProjectManager)
                        : [];
                      projectManagerName =
                        projectManager.length > 0 ? projectManager[0].name : "-";
                      projectManagerEmail =
                        projectManager.length > 0 ? projectManager[0].email : "";
                    } catch (error) {
                      projectManagerName = "-";
                    }
                    const rowData = createData(
                      row.ProjectId,
                      row.ProjectName,
                      projectManagerName,
                      projectManagerEmail,
                      row.ProjectStatus
                    );

                    return (
                      <Row
                        key={rowData.projectId}
                        row={rowData}
                        projectProps={props.projectProps}
                        handleDeleteIconClick={handleDeleteIconClick}
                        handleEditIconClick={handleEditIconClick}
                        topNavigationMode={props.topNavigationMode}
                      />
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={9}>
                      <Box sx={{ textAlign: "center",fontWeight: "600",   fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"}}>
                        No data found
                      </Box>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
      </Grid>
    </div>
  );

};

export default ProjectTable;
