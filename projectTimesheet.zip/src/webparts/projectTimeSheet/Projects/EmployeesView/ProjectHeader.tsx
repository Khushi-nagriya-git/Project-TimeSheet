import { Dropdown, IDropdownOption, Label, SearchBox, IconButton } from '@fluentui/react';
import { Grid } from '@mui/material';
import * as React from 'react';
import { useState } from 'react';

interface ProjectHeaderProps {
  onProjectFilterChange: (selectedValues: string[]) => void;
  onProjectStatusChange: (selectedValues: string[]) => void;
  setSearchQuery: React.Dispatch<React.SetStateAction<string>>;
  setFilteredProjects: React.Dispatch<React.SetStateAction<any>>;
  filteredProjects:any;
  searchQuery: string;
  projectsData: any;
}

const ProjectHeader:React.FC<ProjectHeaderProps> = ({ projectsData ,onProjectFilterChange,onProjectStatusChange,setSearchQuery ,searchQuery,setFilteredProjects}) => {
  const [selectedProject, setSelectedProject] = useState<string[]>([]);
  const [selectedStatus, setSelectedStatus] = useState<string[]>([]);
  const statusOptions = ['Not Started', 'In Progress', 'Completed', 'On Hold'];
 

  const handleProjectChange = (event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption): void => {
    if (option) {
      const selectedValues = option.selected
        ? [...selectedProject, option.key as string]
        : selectedProject.filter((key) => key !== (option.key as string));
      setSelectedProject(selectedValues);
      onProjectFilterChange(selectedValues);
    }
  };

  const handleStatusChange = (event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption): void => {
    if (option) {
      const selectedValues = option.selected
        ? [...selectedStatus, option.key as string]
        : selectedStatus.filter((key) => key !== option.key as string);
      setSelectedStatus(selectedValues);
      onProjectStatusChange(selectedValues);
    }
  };

  const resetFilters = () => {
    setSelectedStatus([]);
    setSelectedProject([]);
    setSearchQuery('');
    setFilteredProjects(projectsData);
  };

  return (
    <div>
      <Grid container spacing={1} alignItems="center">
        <Grid item>
          <Label style={{ fontWeight: '600' }}>Project Name</Label>
          <Dropdown
            placeholder="All"
            selectedKeys={selectedProject}
            onChange={handleProjectChange}
            multiSelect
            options={projectsData.map((project: any) => ({
              key: project.ProjectName,
              text: project.ProjectName,
              selected: selectedProject.indexOf(project.ProjectName) > -1,
              checkbox: true,
            }))}
            styles={{
              root: {
                width: 200,
                height: 60,
                marginBottom: 5,
                borderWidth: 2,
              },
              title: {
                textAlign: 'left',
                lineHeight: '25px',
              },
              dropdownItemsWrapper: {
                maxHeight: 200,
              },
              dropdownItem: {
                height: 35,
                borderRadius: 5,
                width: 200,
                backgroundColor: '#ffffff',
              },
            }}
          />
        </Grid>

        <Grid item>
          <Label style={{ fontWeight: '600' }}>Status</Label>
          <Dropdown
            placeholder="All"
            selectedKeys={selectedStatus}
            onChange={handleStatusChange}
            multiSelect
            options={statusOptions.map((status) => ({
              key: status,
              text: status,
              selected: selectedStatus.indexOf(status) > -1,
              checkbox: true,
            }))}
            styles={{
              root: {
                width: 200,
                height: 60,
                marginBottom: 5,
                borderWidth: 2,
              },
              title: {
                textAlign: 'left',
                lineHeight: '25px',
              },
              dropdownItemsWrapper: {
                maxHeight: 200,
              },
              dropdownItem: {
                height: 35,
                borderRadius: 5,
                width: 200,
                backgroundColor: '#ffffff',
              },
            }}
          />
        </Grid>

        <Grid
          item
          sx={{
            marginLeft: 'auto',
            display: 'flex',
            alignItems: 'center',
          }}
        >
          <SearchBox
          style={{height:"30px"}}
            placeholder="Search by project and status"
            value={searchQuery}
            onChange={(e) => setSearchQuery((e as React.ChangeEvent<HTMLInputElement>).target.value)}
            onClear={() => setSearchQuery('')}
            styles={{
              root: {
                width: 250,
                height: 32,
                margin: '13px 0 10px',
                backgroundColor: '#ffffff',
                padding: '0 5px',
                marginBottom:"15px"
              },
              field: {
                height: 32,
                backgroundColor: '#ffffff',
                padding: '0 6px',
              },
            }}
          />

          <IconButton
            iconProps={{ iconName: 'ArrowUpRightMirrored8' }}
            onClick={resetFilters}
            styles={{
              root: {
                height: 31,
                width: 31, // Adjusted width for the IconButton
                marginLeft: 10,
                border: '1px solid rgba(0, 0, 0, 0.4)',
                backgroundColor: '#ffffff',
                marginBottom: 10,
                marginTop:8
              },
            }}
          />
        </Grid>
      </Grid>
    </div>
  );
};

export default ProjectHeader;
