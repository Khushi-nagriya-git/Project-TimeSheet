import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { useEffect } from 'react';

const DepartmentView = (props:{ projectsData:any, projectProps:any, selectedProjectName: any,
  searchQuery:any, selectedStatusName: any,   filteredProjects:any,  setFilteredProjects: React.Dispatch<React.SetStateAction<any>>;
}) => {
  
    useEffect(() => {
  
  let filteredByName = props.projectsData.filter((project: { ProjectName: string }) =>
    props.selectedProjectName.includes(project.ProjectName)
  );

  if (filteredByName.length <= 0) filteredByName = props.projectsData;

  let filteredByStatus = filteredByName.filter((project: { ProjectStatus: string }) =>
    props.selectedStatusName.includes(project.ProjectStatus)
  );

  if (filteredByStatus.length <= 0) filteredByStatus = filteredByName;

  let filteredBySearchQuery = filteredByStatus.filter((project: any) => {
    return (
      project.ProjectName.toLowerCase().includes(props.searchQuery.toLowerCase()) ||
      project.ProjectStatus.toLowerCase().includes(props.searchQuery.toLowerCase())
    );
  });

  if (props.searchQuery === '') filteredBySearchQuery = filteredByStatus;

  props.setFilteredProjects(filteredBySearchQuery);


}, [props.selectedProjectName, props.selectedStatusName, props.projectsData, props.searchQuery]);


  return (
    <div style={{height:"240px",marginTop: "-15px", overflowY: 'auto' }}>
    <TableContainer>
      <Table stickyHeader aria-label="sticky table">
        <TableHead sx={{ backgroundColor: "#f3f2f1", fontWeight: "600",height:"40px" , fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"}}>
          <TableRow>
            <TableCell sx={{ fontWeight: "600",backgroundColor: "#f3f2f1" ,height:"20px"  ,  fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"}}>Project Name</TableCell>
            <TableCell sx={{ fontWeight: "600",backgroundColor: "#f3f2f1",height:"20px" ,  fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"}}>Department</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {props.filteredProjects.map((project: any) => (
            <TableRow key={project.ProjectId}>
              <TableCell>{project.ProjectName}</TableCell>
              <TableCell>{project.DepartmentsORTeam}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    </div>
  );
};

export default DepartmentView;
