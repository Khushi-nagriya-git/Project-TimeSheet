import * as React from "react";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Button,
  IconButton,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";

interface CannotDeleteDialogBoxProps {
  open: boolean;
  handleClose: () => void;
}

const CannotDeleteDialogBox: React.FC<CannotDeleteDialogBoxProps> = ({
  open,
  handleClose,
}) => {
  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <DialogTitle
        id="alert-dialog-title"
        style={{
          marginTop: "0px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        {"Project Deletion Not Allowed"}
        <IconButton aria-label="close" onClick={handleClose} sx={{ color: "grey" }}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent>
        <DialogContentText id="alert-dialog-description" sx={{ color: "rgb(50, 49, 48)" }}>
        This project cannot be deleted as it contains associated jobs.
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button
          onClick={handleClose}
          autoFocus
          sx={{
            backgroundColor: "#1565c0",
            color: "white",
            "&:hover": {
              backgroundColor: "#0069D9",
            },
          }}
        >
          Okay
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CannotDeleteDialogBox;
