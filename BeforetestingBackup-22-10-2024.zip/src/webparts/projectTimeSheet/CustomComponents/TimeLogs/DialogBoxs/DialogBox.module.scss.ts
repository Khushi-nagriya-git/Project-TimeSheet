/* tslint:disable */
require("./DialogBox.module.css");
const styles = {
  dialogTitle: 'dialogTitle_6da6c5b1',
  buttonIcon: 'buttonIcon_6da6c5b1',
  dialogContentText: 'dialogContentText_6da6c5b1',
  deleteButton: 'deleteButton_6da6c5b1'
};

export default styles;
/* tslint:enable */