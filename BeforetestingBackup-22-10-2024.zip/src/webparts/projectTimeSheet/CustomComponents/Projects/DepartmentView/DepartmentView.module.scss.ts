/* tslint:disable */
require("./DepartmentView.module.css");
const styles = {
  Box: 'Box_6f31967e',
  tableHeadcss: 'tableHeadcss_6f31967e',
  tableCellcss: 'tableCellcss_6f31967e'
};

export default styles;
/* tslint:enable */