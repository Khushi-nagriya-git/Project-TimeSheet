import * as React from 'react';
import { ReactNode } from 'react';
import { ProjectsData } from './CustomComponents/Projects/IProjectStats';
import { JobsData } from './CustomComponents/Jobs/IJobsStats';
import { TimeLogsData } from './CustomComponents/TimeLogs/ITimeLogsStats';
interface EmployeeTimeSheetContextType {
    projectsData: ProjectsData[];
    setProjectsData: React.Dispatch<React.SetStateAction<ProjectsData[]>>;
    isUserReportingManager: boolean;
    setIsUserReportingManager: React.Dispatch<React.SetStateAction<boolean>>;
    isUserProjectManager: boolean;
    setIsUserProjectManager: React.Dispatch<React.SetStateAction<boolean>>;
    isUserAdmin: boolean;
    setUserAdmin: React.Dispatch<React.SetStateAction<boolean>>;
    isUserProjectTeam: boolean;
    setIsUserProjectTeam: React.Dispatch<React.SetStateAction<boolean>>;
    loggedInUserDetails: any;
    setLoggedInUserDetails: React.Dispatch<React.SetStateAction<any>>;
    jobsData: JobsData[];
    setJobsData: React.Dispatch<React.SetStateAction<JobsData[]>>;
    timeLogsData: TimeLogsData[];
    setTimeLogsData: React.Dispatch<React.SetStateAction<[]>>;
    siteUsers: [];
    setSiteUsers: React.Dispatch<React.SetStateAction<[]>>;
}
export declare const EmployeeTimeSheetProvider: React.FC<{
    children: ReactNode;
}>;
export declare const useEmployeeTimeSheetContext: () => EmployeeTimeSheetContextType;
export {};
//# sourceMappingURL=EmployeeTimeSheetContext.d.ts.map