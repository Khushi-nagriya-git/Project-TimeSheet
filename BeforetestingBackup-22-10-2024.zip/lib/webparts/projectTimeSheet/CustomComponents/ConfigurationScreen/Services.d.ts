import { SPHttpClient } from "../../../..";
export declare const updateData: (formData: any, applicationTitle: string, absoluteURL: string, spHttpClient: any) => Promise<boolean>;
export declare const handleUploadAttachment: (itemId: number, file: File, absoluteURL: string, spHttpClient: SPHttpClient) => Promise<boolean>;
export declare const addData: (formData: any, applicationTitle: string, absoluteURL: any, spHttpClient: any) => Promise<true | undefined>;
//# sourceMappingURL=Services.d.ts.map