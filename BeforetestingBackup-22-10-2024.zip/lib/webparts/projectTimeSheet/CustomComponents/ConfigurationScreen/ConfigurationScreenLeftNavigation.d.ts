import * as React from "react";
declare const ConfigurationScreenLeftNavigation: (props: {
    setTab: React.Dispatch<React.SetStateAction<any>>;
}) => JSX.Element;
export default ConfigurationScreenLeftNavigation;
//# sourceMappingURL=ConfigurationScreenLeftNavigation.d.ts.map