import { IProjectProps } from "../../../../../index";
declare const Row: (props: {
    row: ReturnType<any>;
    projectProps: IProjectProps;
    handleEditIconClick: any;
    loggedInUserDetails: any;
    handleDeleteIconClick: any;
}) => JSX.Element;
export default Row;
//# sourceMappingURL=JobTableRows.d.ts.map