export interface JobAssginees {
    name: string;
    email: string;
    id: any;
    estimatedHours: number;
    loggedHours: number;
}
export interface JobFormData {
    jobName: string;
    jobId: number;
    projectName: string;
    projectId: string | number | undefined;
    startDate: any;
    endDate: any;
    JobAssigness: JobAssginees[];
    description: string;
    billableStatus: string;
    jobStatus: string;
    estimatedHours: number;
    loggedHours: number;
    attachment: any;
    AssignedToPeoplePicker: any;
    Author: {
        EMail: string;
    };
}
export declare const initialState: {
    jobFormData: JobFormData;
};
//# sourceMappingURL=IJobFormStats.d.ts.map