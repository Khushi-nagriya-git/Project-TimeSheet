import * as React from "react";
import { IJobsProps } from "./IJobsProps";
declare const Jobs: React.FC<IJobsProps>;
export default Jobs;
//# sourceMappingURL=Jobs.d.ts.map