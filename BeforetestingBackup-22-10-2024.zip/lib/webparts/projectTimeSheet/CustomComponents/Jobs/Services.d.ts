/// <reference types="react" />
import { SPHttpClient } from "@microsoft/sp-http";
import { JobFormData } from "../Jobs/Forms/IJobFormStats";
export declare const getJobListData: (absoluteURL: string, spHttpClient: SPHttpClient, setJobsData: React.Dispatch<React.SetStateAction<any>>, loggedInUserDetails: any, projectsData: any, isUserAdmin: any) => Promise<void>;
export declare const getLastJobId: (absoluteURL: string, spHttpClient: SPHttpClient) => Promise<number>;
export declare const convertToMinutes: (value: number) => number;
export declare const addJobs: (data: JobFormData, absoluteURL: string, spHttpClient: SPHttpClient) => Promise<void>;
export declare const handleUploadAttachment: (itemId: number, file: File, absoluteURL: string, spHttpClient: SPHttpClient) => Promise<import("@microsoft/sp-http-base").SPHttpClientResponse>;
export declare const deleteJobs: (absoluteURL: string, spHttpClient: SPHttpClient, jobId: number, setJobsData: React.Dispatch<React.SetStateAction<any>>) => Promise<void>;
export declare function updateJobRecords(spHttpClient: SPHttpClient, absoluteURL: string, jobId: number, updateformData: any, type: string, setJobsData: React.Dispatch<React.SetStateAction<any>>, setCurrentData: React.Dispatch<React.SetStateAction<any>>, loggedInUserDetails: any): Promise<void>;
//# sourceMappingURL=Services.d.ts.map