import * as React from "react";
declare const TopNavigation: (props: {
    setTopNavigationState: React.Dispatch<React.SetStateAction<any>>;
    setTopNavigationMode: React.Dispatch<React.SetStateAction<any>>;
}) => JSX.Element;
export default TopNavigation;
//# sourceMappingURL=TopNavigation.d.ts.map