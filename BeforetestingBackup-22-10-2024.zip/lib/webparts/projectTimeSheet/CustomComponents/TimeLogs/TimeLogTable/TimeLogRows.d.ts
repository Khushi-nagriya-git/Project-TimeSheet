import { React } from "../../../../../index";
declare const TimeLogRows: (props: {
    row: ReturnType<any>;
    handleDeleteIconClick: any;
    handleEditIconClick: any;
    timelogProps: any;
    isRunning: any;
    elapsedTime: any;
    handleStartStop: any;
    jobResumeTimer: any;
    setIsRunning: React.Dispatch<React.SetStateAction<any>>;
}) => JSX.Element;
export default TimeLogRows;
//# sourceMappingURL=TimeLogRows.d.ts.map