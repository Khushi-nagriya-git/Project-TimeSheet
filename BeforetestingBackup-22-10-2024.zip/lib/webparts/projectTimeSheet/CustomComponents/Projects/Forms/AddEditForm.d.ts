/// <reference types="react" />
import { React, IFormProps } from "../../../../../index";
declare const FormComponent: React.FC<IFormProps>;
export default FormComponent;
//# sourceMappingURL=AddEditForm.d.ts.map