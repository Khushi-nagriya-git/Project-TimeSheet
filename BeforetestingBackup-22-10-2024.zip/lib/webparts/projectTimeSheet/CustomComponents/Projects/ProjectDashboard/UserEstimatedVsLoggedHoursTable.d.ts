import { WebPartContext } from "@microsoft/sp-webpart-base";
declare const UserEstimatedVsLoggedHoursTable: (props: {
    data: any;
    columnName: any;
    context: WebPartContext;
}) => JSX.Element;
export default UserEstimatedVsLoggedHoursTable;
//# sourceMappingURL=UserEstimatedVsLoggedHoursTable.d.ts.map