import { IProjectProps } from "../../../../../index";
declare const Row: (props: {
    row: ReturnType<any>;
    projectProps: IProjectProps;
    handleDeleteIconClick: any;
    handleEditIconClick: any;
    topNavigationMode: any;
    isUserReportingManager: any;
    isUserProjectManager: any;
    isUserAdmin: any;
    isUserProjectTeam: any;
    loggedInUserDetails: any;
}) => JSX.Element;
export default Row;
//# sourceMappingURL=TableRows.d.ts.map