/* tslint:disable */
require("./AppHeader.module.css");
const styles = {
  bt_ah_AppHeader: 'bt_ah_AppHeader_22504a26',
  bt_ah_CompanyLogo: 'bt_ah_CompanyLogo_22504a26',
  bt_ah_HeaderText: 'bt_ah_HeaderText_22504a26',
  bt_ah_UserName: 'bt_ah_UserName_22504a26',
  bt_ah_HomeIcon: 'bt_ah_HomeIcon_22504a26'
};

export default styles;
/* tslint:enable */