/* tslint:disable */
require("./JobForm.module.css");
const styles = {
  drawerStyle: 'drawerStyle_4315b8bf',
  drawerDiv: 'drawerDiv_4315b8bf',
  drawerTitle: 'drawerTitle_4315b8bf',
  row: 'row_4315b8bf',
  textField: 'textField_4315b8bf',
  dropdown: 'dropdown_4315b8bf',
  textFieldMultiline: 'textFieldMultiline_4315b8bf',
  'ms-TextField-field': 'ms-TextField-field_4315b8bf',
  peoplePickerWrapper: 'peoplePickerWrapper_4315b8bf',
  label: 'label_4315b8bf'
};

export default styles;
/* tslint:enable */