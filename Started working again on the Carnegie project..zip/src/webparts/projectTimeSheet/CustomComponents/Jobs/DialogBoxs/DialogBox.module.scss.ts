/* tslint:disable */
require("./DialogBox.module.css");
const styles = {
  dialogTitle: 'dialogTitle_3c7f21ad',
  buttonIcon: 'buttonIcon_3c7f21ad',
  dialogContentText: 'dialogContentText_3c7f21ad',
  deleteButton: 'deleteButton_3c7f21ad'
};

export default styles;
/* tslint:enable */