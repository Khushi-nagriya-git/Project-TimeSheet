/* tslint:disable */
require("./ProjectTimeSheet.module.css");
const styles = {
  searchContainer: 'searchContainer_4eca9ac7'
};

export default styles;
/* tslint:enable */