import { WebPartContext } from "@microsoft/sp-webpart-base";
declare const DashBoardLeftHeader: (props: {
    project: any;
    context: WebPartContext;
    team: number;
}) => JSX.Element;
export default DashBoardLeftHeader;
//# sourceMappingURL=DashBoardLeftHeader.d.ts.map