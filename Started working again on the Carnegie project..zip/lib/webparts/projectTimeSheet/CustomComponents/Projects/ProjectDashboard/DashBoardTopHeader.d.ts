declare const DashBoardTopHeader: (props: {}) => JSX.Element;
export default DashBoardTopHeader;
//# sourceMappingURL=DashBoardTopHeader.d.ts.map