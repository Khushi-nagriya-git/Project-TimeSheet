declare const DashBoardBody: (props: {
    data: any;
    label: string;
    status: any;
    type: string;
    centerValue: any;
}) => JSX.Element;
export default DashBoardBody;
//# sourceMappingURL=DoughnutChart.d.ts.map