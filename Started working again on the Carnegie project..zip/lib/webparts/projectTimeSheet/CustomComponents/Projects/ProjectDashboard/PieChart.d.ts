declare const PieChart: (props: {
    project: any;
    lockedHours: number;
}) => JSX.Element;
export default PieChart;
//# sourceMappingURL=PieChart.d.ts.map