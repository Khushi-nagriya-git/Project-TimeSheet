import * as React from "react";
interface BarChartProps {
    data: any;
    label: string;
    status: any;
}
declare const BarCharts: React.FC<BarChartProps>;
export default BarCharts;
//# sourceMappingURL=BarChart.d.ts.map