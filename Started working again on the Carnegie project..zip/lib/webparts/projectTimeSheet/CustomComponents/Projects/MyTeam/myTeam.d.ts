import { IProjectProps } from "../../../../../index";
declare const MyTeam: (props: {
    spHttpClient: any;
    absoluteURL: any;
    projectProps: IProjectProps;
    isUserAdmin: any;
    isUserProjectManager: any;
    isUserProjectTeam: any;
    isUserReportingManager: any;
    loggedInUserDetails: any;
}) => JSX.Element;
export default MyTeam;
//# sourceMappingURL=myTeam.d.ts.map