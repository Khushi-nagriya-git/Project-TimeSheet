/// <reference types="react" />
import { CustomFormData, SPHttpClient } from "../../../../index";
export declare const getLoggedInUserData: (spHttpClient: SPHttpClient, absoluteURL: string) => Promise<any>;
export declare const getDepartments: (absoluteURL: string, spHttpClient: SPHttpClient, setDepartmentNames: React.Dispatch<React.SetStateAction<any>>, type: string) => Promise<void>;
export declare const getProjectListData: (absoluteURL: string, spHttpClient: SPHttpClient, setProjectsData: React.Dispatch<React.SetStateAction<any>>, loggedInUserDetails: any, isUserAdmin: any) => Promise<any>;
export declare const getLastItemId: (absoluteURL: string, spHttpClient: SPHttpClient) => Promise<number>;
export declare const addProjects: (data: CustomFormData, absoluteURL: string, spHttpClient: SPHttpClient) => Promise<false | undefined>;
export declare const handleUploadAttachment: (itemId: number, file: any, absoluteURL: string, spHttpClient: SPHttpClient) => Promise<import("@microsoft/sp-http-base").SPHttpClientResponse>;
export declare function updateUserRecords(spHttpClient: SPHttpClient, absoluteURL: string, projectId: number, updateformData: CustomFormData, setProjectsData: React.Dispatch<React.SetStateAction<any>>, setCurrentData: React.Dispatch<React.SetStateAction<any>>): Promise<void>;
export declare const deleteProject: (absoluteURL: string, spHttpClient: SPHttpClient, projectId: number, setProjectsData: React.Dispatch<React.SetStateAction<any>>) => Promise<void>;
//# sourceMappingURL=Services.d.ts.map