export interface LoggedInUserDetails {
    Title: string;
    Id: any;
    Email: string;
    Groups: [{
        Title: string;
        Id: number;
    }];
}
export interface ProjectManager {
    name: string;
    cost: number;
}
export interface ProjectsData {
    ProjectName: string;
    ProjectId: number;
    ClientName: string;
    ProjectCost: number;
    ProjectHours: number;
    ReportingManager: [];
    ProjectManager: ProjectManager[];
    ProjectTeam: ProjectManager[];
    Department: string;
    ProjectType: string;
    Description: string;
    Attachment: any;
    ProjectStatus: string;
    ReportingManagerPeoplePicker: {
        EMail: string;
        Title: string;
    };
    ProjectManagerPeoplePicker: {
        EMail: string;
        Title: string;
    };
}
export declare const initialLoggedInUserDetails: LoggedInUserDetails;
export declare const projectsInitialState: {
    projectsData: ProjectsData[];
    loggedInUserDetails: LoggedInUserDetails;
};
//# sourceMappingURL=IProjectStats.d.ts.map