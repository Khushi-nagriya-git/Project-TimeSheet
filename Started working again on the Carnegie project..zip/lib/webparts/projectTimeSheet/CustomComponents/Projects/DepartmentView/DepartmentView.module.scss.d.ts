declare const styles: {
    Box: string;
    tableHeadcss: string;
    tableCellcss: string;
};
export default styles;
//# sourceMappingURL=DepartmentView.module.scss.d.ts.map