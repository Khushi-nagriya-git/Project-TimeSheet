import { React } from "../../../../..";
declare const DepartmentView: (props: {
    projectsData: any;
    projectProps: any;
    selectedProjectName: any;
    searchQuery: any;
    selectedStatusName: any;
    filteredProjects: any;
    selectedDepartmentName: any;
    setFilteredProjects: React.Dispatch<React.SetStateAction<any>>;
}) => JSX.Element;
export default DepartmentView;
//# sourceMappingURL=DepartmentView.d.ts.map