import { React } from "../../../../../index";
declare const TimeLogTable: (props: {
    absoluteURL: any;
    spHttpClient: any;
    loggedInUserDetails: any;
    isUserAdmin: any;
    timelogProps: any;
    filteredTimeLogsData: any;
    isUserReportingManager: any;
    currentUserDetails: any;
    isRunning: any;
    elapsedTime: any;
    setTimeLogsData: React.Dispatch<React.SetStateAction<any>>;
    timeLogsData: any;
    jobResumeTimer: any;
    handleStartStop: any;
    setDeletedTimelogId: React.Dispatch<React.SetStateAction<any>>;
    setIsOpen: React.Dispatch<React.SetStateAction<any>>;
    setIsRunning: React.Dispatch<React.SetStateAction<any>>;
    setEditTimeLogId: React.Dispatch<React.SetStateAction<any>>;
    setInitialFormData: React.Dispatch<React.SetStateAction<any>>;
    setEditFormOpen: React.Dispatch<React.SetStateAction<any>>;
}) => JSX.Element;
export default TimeLogTable;
//# sourceMappingURL=TimeLogTable.d.ts.map