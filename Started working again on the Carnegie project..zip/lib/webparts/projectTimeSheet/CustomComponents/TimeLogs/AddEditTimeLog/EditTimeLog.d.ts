import { React } from "../../../../../index";
declare const EditTimeLog: (props: {
    setEditFormOpen: React.Dispatch<React.SetStateAction<any>>;
    setInitialFormData: React.Dispatch<React.SetStateAction<any>>;
    initialFormData: any;
    onSubmit: any;
    open: any;
    projectsData: any;
    jobsData: any;
    isUserProjectManager: any;
    loggedInUserDetails: any;
    isUserProjectTeam: any;
    isUserReportingManager: any;
}) => JSX.Element;
export default EditTimeLog;
//# sourceMappingURL=EditTimeLog.d.ts.map