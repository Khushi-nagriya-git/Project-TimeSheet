import * as React from "react";
import { IJobFormProps } from "./IJobFormProps";
declare const JobForm: React.FC<IJobFormProps>;
export default JobForm;
//# sourceMappingURL=JobForm.d.ts.map