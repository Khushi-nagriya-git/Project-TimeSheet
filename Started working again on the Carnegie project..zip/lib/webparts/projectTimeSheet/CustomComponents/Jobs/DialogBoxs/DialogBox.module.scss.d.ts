declare const styles: {
    dialogTitle: string;
    buttonIcon: string;
    dialogContentText: string;
    deleteButton: string;
};
export default styles;
//# sourceMappingURL=DialogBox.module.scss.d.ts.map