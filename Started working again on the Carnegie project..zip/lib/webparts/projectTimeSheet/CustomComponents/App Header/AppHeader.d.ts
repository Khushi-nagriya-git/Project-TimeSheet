export default function AppHeader(props: {
    userEmail: string;
    siteURL: string;
    userName: string;
    title: any;
    logo: any;
    absoluteURL: string;
}): JSX.Element;
//# sourceMappingURL=AppHeader.d.ts.map