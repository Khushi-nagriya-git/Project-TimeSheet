declare const styles: {
    bt_ah_AppHeader: string;
    bt_ah_CompanyLogo: string;
    bt_ah_HeaderText: string;
    bt_ah_UserName: string;
    bt_ah_HomeIcon: string;
};
export default styles;
//# sourceMappingURL=AppHeader.module.scss.d.ts.map