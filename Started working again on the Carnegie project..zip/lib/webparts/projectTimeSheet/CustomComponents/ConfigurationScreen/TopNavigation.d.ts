declare const TopNavigation: (props: {
    heading: string;
}) => JSX.Element;
export default TopNavigation;
//# sourceMappingURL=TopNavigation.d.ts.map