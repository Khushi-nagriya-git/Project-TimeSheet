import * as React from "react";
import { IConfigurationScreenProps } from "./IConfigurationScreenProps";
declare const ConfigurationScreen: React.FC<IConfigurationScreenProps>;
export default ConfigurationScreen;
//# sourceMappingURL=ConfigurationScreen.d.ts.map