import * as React from "react";
import { WebPartContext } from "@microsoft/sp-webpart-base";
declare const GeneralSettings: (props: {
    context: WebPartContext;
    absoluteURL: string;
    title: string;
    spHttpClient: any;
    configurationListDataLength: number;
    configurationListData: any;
    setReload: React.Dispatch<React.SetStateAction<any>>;
}) => JSX.Element;
export default GeneralSettings;
//# sourceMappingURL=GeneralSettings.d.ts.map