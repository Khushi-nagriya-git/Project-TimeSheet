import * as React from "react";
import { ITimeSheetProps } from "./ITimeSheetProps";
declare const TimeSheet: React.FC<ITimeSheetProps>;
export default TimeSheet;
//# sourceMappingURL=TimeSheet.d.ts.map