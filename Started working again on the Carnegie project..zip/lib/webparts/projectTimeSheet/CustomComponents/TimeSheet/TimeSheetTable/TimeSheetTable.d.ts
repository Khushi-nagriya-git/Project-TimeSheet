import { React } from "../../../../../index";
import { ITimeSheetProps } from "../ITimeSheetProps";
declare const TimeSheetTable: (props: {
    absoluteURL: any;
    spHttpClient: any;
    loggedInUserDetails: any;
    timeLogsData: any;
    myDataActiveLink: any;
    TableType: any;
    updateStatus: any;
    TimeSheetProps: ITimeSheetProps;
    handleTabChange: (tab: string) => Promise<void>;
    setUpdateStatus: React.Dispatch<React.SetStateAction<any>>;
}) => JSX.Element;
export default TimeSheetTable;
//# sourceMappingURL=TimeSheetTable.d.ts.map