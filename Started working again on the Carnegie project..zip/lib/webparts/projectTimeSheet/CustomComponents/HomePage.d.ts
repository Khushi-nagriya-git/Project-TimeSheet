declare const HomePage: () => JSX.Element;
export default HomePage;
//# sourceMappingURL=HomePage.d.ts.map