import * as React from "react";
import type { IProjectTimeSheetProps } from "./IProjectTimeSheetProps";
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/batching';
declare const ProjectTimeSheet: React.FC<IProjectTimeSheetProps>;
export default ProjectTimeSheet;
//# sourceMappingURL=ProjectTimeSheet.d.ts.map