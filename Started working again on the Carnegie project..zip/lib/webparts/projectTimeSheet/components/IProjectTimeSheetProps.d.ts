import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IProjectTimeSheetProps {
    spHttpClient: any;
    absoluteURL: any;
    context: WebPartContext;
    title: any;
    Attachment: any;
}
//# sourceMappingURL=IProjectTimeSheetProps.d.ts.map