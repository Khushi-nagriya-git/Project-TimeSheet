import { SPHttpClient } from "../../..";
export declare const getAllSiteUsers: (spHttpClient: SPHttpClient, absoluteURL: string) => Promise<any>;
export declare const getConfigurationListData: (spHttpClient: SPHttpClient, absoluteURL: string) => Promise<any>;
//# sourceMappingURL=Service.d.ts.map