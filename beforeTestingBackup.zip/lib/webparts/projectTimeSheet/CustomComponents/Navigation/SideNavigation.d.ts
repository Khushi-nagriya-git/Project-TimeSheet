declare const SideNavigation: () => JSX.Element;
export default SideNavigation;
//# sourceMappingURL=SideNavigation.d.ts.map