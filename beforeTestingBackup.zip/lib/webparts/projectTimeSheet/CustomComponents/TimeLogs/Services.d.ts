/// <reference types="react" />
import { SPHttpClient } from "../../../..";
import { TimeLogsData } from "./ITimeLogsStats";
export declare const getTimeLogsListData: (absoluteURL: string, spHttpClient: SPHttpClient, setTimeLogsData: React.Dispatch<React.SetStateAction<any>>, loggedInUserDetails: {
    Email: string;
} | null, type: string, isUserAdmin: boolean, isUserReportingManager: boolean) => Promise<any>;
export declare const getLastItemId: (absoluteURL: string, spHttpClient: SPHttpClient) => Promise<number>;
export declare const addTimeLogs: (data: TimeLogsData, absoluteURL: string, spHttpClient: SPHttpClient, jobsData: any, setTimeLogsData: React.Dispatch<React.SetStateAction<any>>) => Promise<void>;
export declare function updateRecords(spHttpClient: SPHttpClient, absoluteURL: string, updateType: string, LockedMinutes: number, updateddata: any, // This can be an array when updating multiple rows
editTimeLogId: number, setUpdateStatus: React.Dispatch<React.SetStateAction<any>>): Promise<void>;
export declare const deleteTimelog: (absoluteURL: string, spHttpClient: SPHttpClient, timelogId: number, setTimeLogsData: React.Dispatch<React.SetStateAction<any>>) => Promise<void>;
//# sourceMappingURL=Services.d.ts.map