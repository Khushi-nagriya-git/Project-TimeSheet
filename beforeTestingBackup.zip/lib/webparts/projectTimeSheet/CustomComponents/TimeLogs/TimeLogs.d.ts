import * as React from "react";
import { ITimeLogsProps } from "./ITimeLogsProps";
declare const TimeLogs: React.FC<ITimeLogsProps>;
export default TimeLogs;
//# sourceMappingURL=TimeLogs.d.ts.map