export interface TimeLogsData {
    TimelogsId: number;
    ProjectId: number;
    ProjectName: string;
    JobId: number;
    JobName: string;
    BillableStatus: string;
    Description: string;
    LoggedHours: number;
    EstimatedHours: number;
    Status: string;
    Created: '';
    CreatedBy: any;
    Author: any;
}
export interface CurrentUserDetails {
    Title: string;
    Id: any;
    email: string;
    groups: [];
}
export declare const timeLogsDataInitialState: {
    timeLogsData: TimeLogsData;
    currentUserData: CurrentUserDetails;
};
//# sourceMappingURL=ITimeLogsStats.d.ts.map