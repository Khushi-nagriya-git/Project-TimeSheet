import { SPHttpClient } from "../../../../index";
declare const DepartmentSetting: (props: {
    absoluteURL: string;
    spHttpClient: SPHttpClient;
}) => JSX.Element;
export default DepartmentSetting;
//# sourceMappingURL=DepartmentSetting.d.ts.map