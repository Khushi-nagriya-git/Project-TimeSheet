declare const styles: {
    drawerStyle: string;
    drawerDiv: string;
    drawerTitle: string;
    row: string;
    textField: string;
    dropdown: string;
    textFieldMultiline: string;
    'ms-TextField-field': string;
    peoplePickerWrapper: string;
    label: string;
};
export default styles;
//# sourceMappingURL=JobForm.module.scss.d.ts.map