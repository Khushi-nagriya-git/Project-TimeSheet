export interface JobAssginees {
    name: string;
    cost: number;
    estimatedHours: number;
}
export interface JobsData {
    JobName: string;
    JobId: number;
    ProjectName: string;
    ProjectId: any;
    StartDate: any;
    EndDate: any;
    JobAssginees: JobAssginees[];
    Description: string;
    BillableStatus: string;
    JobStatus: string;
    EstimatedHours: number;
    loggedHours: number;
    Attachment: any;
    AssignedToPeoplePicker: [{
        EMail: string;
        Title: string;
    }];
    Author: {
        EMail: string;
        Title: string;
    };
}
export declare const initialJobsData: JobsData;
export declare const jobsInitialState: {
    jobsData: JobsData[];
};
//# sourceMappingURL=IJobsStats.d.ts.map