import * as React from "react";
declare const TimeSheetForm: ({ open, onClose, selectedData, absoluteURL, spHttpClient, setUpdateStatus, updateStatus, TableType, handleTabChange, setApprovedAlert, setAlert, setRejectAlert, setSelected, selected, }: {
    open: boolean;
    onClose: () => void;
    handleTabChange: (tab: string) => Promise<void>;
    selectedData: any[];
    absoluteURL: any;
    spHttpClient: any;
    selected: any;
    setSelected: React.Dispatch<React.SetStateAction<any>>;
    setUpdateStatus: React.Dispatch<React.SetStateAction<any>>;
    setApprovedAlert: React.Dispatch<React.SetStateAction<any>>;
    setRejectAlert: React.Dispatch<React.SetStateAction<any>>;
    setAlert: React.Dispatch<React.SetStateAction<any>>;
    updateStatus: any;
    TableType: any;
}) => JSX.Element | null;
export default TimeSheetForm;
//# sourceMappingURL=ApproveRejectForm.d.ts.map