/// <reference types="react" />
import { React } from "../../../../../index";
interface DeleteDialogBoxProps {
    open: boolean;
    handleClose: () => void;
    handleDeleteAction: () => void;
    isJobAvailable: boolean;
}
declare const DeleteDialogBox: React.FC<DeleteDialogBoxProps>;
export default DeleteDialogBox;
//# sourceMappingURL=DeleteDialogBox.d.ts.map