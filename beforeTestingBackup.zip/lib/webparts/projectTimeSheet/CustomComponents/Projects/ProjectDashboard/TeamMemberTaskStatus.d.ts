import { WebPartContext } from "@microsoft/sp-webpart-base";
declare const TeamMemberTaskStatus: (props: {
    data: any;
    columnName: any;
    context: WebPartContext;
}) => JSX.Element;
export default TeamMemberTaskStatus;
//# sourceMappingURL=TeamMemberTaskStatus.d.ts.map